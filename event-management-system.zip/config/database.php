<?php

return [
    'db' => [
        'host' => 'mysql-10d95588-mehedihasanhasib98-0269.b.aivencloud.com',
        'port' => 13849,
        'dbname' => 'ollyo-test',
        'username' => 'avnadmin',
        'password' => 'AVNS_zZVrffogLuEb-tKu4CG',

        // 'host' => 'localhost',
        // 'port' => 3306,
        // 'dbname' => 'hasibinf_ollyotest',
        // 'username' => 'hasibinf_hasib',
        // 'password' => '8oK_e{2k2feW',
    ],
];
