<?php
session_start();

define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . "/app/Helpers/functions.php";

require_once BASE_PATH . "/public/autoload.php";

require_once BASE_PATH . "/bootstrap/app.php";