<?php
namespace App\Helpers;

use App\Core\Database;

class DB extends Database
{
    //
}