<?php

namespace App\Models;

use App\Core\Model;


class Event extends Model
{
    protected $table = 'events';
}
