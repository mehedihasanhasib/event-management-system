<?php

namespace App\Models;

use App\Core\Model;



class Location extends Model
{
    protected $table = 'locations';
}
